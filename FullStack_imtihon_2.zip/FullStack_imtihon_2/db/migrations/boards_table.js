exports.up = function(knex) {
    return knex.schema.createTable('boards', (table) => {
      table.increments('id').primary();
      table.string('title').notNullable();
      table.json('columns').nullable();
    });
  };
  
  exports.down = function(knex) {
    return knex.schema.dropTable('boards');
  };