module.exports = {
    development: {
      client: 'pg',
      connection: {
        host: '127.0.0.1',
        user: 'your_username',
        password: 'your_password',
        database: 'nodejs_trello'
      },
      migrations: {
        directory: './db/migrations'
      },
      useNullAsDefault: true,
    },
  };

