/*

#### 1.2. Loyiha tuzilmasi

Loyiha tuzilmasi quyidagicha bo'ladi:

```
nodejs-trello-service/
├── db/
│   └── migrations/
│   └── knexfile.js
├── models/
│   ├── User.js
│   ├── Board.js
│   └── Task.js
├── routes/
│   ├── auth.js
│   ├── users.js
│   ├── boards.js
│   └── tasks.js
├── app.js
└── package.json
```

### 2. Ma'lumotlar Bazasini Sozlash

#### 2.1. Knex va SQLite Sozlash

`knexfile.js` faylini yarating va unda quyidagi kodni yozing:

```js
// db/knexfile.js
module.exports = {
  development: {
    client: 'sqlite3',
    connection: {
      filename: './db/dev.sqlite3'
    },
    useNullAsDefault: true,
  },
};
```

#### 2.2. Ma'lumotlar bazasi jadval migratsiyalari

Migratsiyalar yaratish uchun quyidagi buyruqlarni bajaring:

```sh
npx knex init
npx knex migrate:make create_users_table
npx knex migrate:make create_boards_table
npx knex migrate:make create_tasks_table
```

Keyin har bir migratsiya faylini quyidagi kabi to'ldiring:

```js
// migrations/[timestamp]_create_users_table.js
exports.up = function(knex) {
  return knex.schema.createTable('users', (table) => {
    table.increments('id').primary();
    table.string('name').notNullable();
    table.string('email').unique().notNullable();
    table.string('password').notNullable();
  });
};

exports.down = function(knex) {
  return knex.schema.dropTable('users');
};
```

```js
// migrations/[timestamp]_create_boards_table.js
exports.up = function(knex) {
  return knex.schema.createTable('boards', (table) => {
    table.increments('id').primary();
    table.string('title').notNullable();
    table.json('columns').nullable();
  });
};

exports.down = function(knex) {
  return knex.schema.dropTable('boards');
};
```

```js
// migrations/[timestamp]_create_tasks_table.js
exports.up = function(knex) {
  return knex.schema.createTable('tasks', (table) => {
    table.increments('id').primary();
    table.string('title').notNullable();
    table.integer('order').notNullable();
    table.string('description').nullable();
    table.integer('userId').references('id').inTable('users');
    table.integer('boardId').references('id').inTable('boards');
    table.integer('columnId').nullable();
  });
};

exports.down = function(knex) {
  return knex.schema.dropTable('tasks');
};
```

Keyin migratsiyalarni ishlating:

```sh
npx knex migrate:latest
```

### 3. Model Fayllari

`models` papkasida har bir model uchun fayl yarating:

#### 3.1. User modeli

```js
// models/User.js
const knex = require('../db/knex');

class User {
  static async create(user) {
    return await knex('users').insert(user).returning('*');
  }

  static async findByEmail(email) {
    return await knex('users').where({ email }).first();
  }

  static async findById(id) {
    return await knex('users').where({ id }).first();
  }

  static async getAll() {
    return await knex('users').select('id', 'name', 'email');
  }

  static async update(id, user) {
    return await knex('users').where({ id }).update(user).returning('*');
  }

  static async delete(id) {
    return await knex('users').where({ id }).del();
  }
}

module.exports = User;
```

#### 3.2. Board modeli

```js
// models/Board.js
const knex = require('../db/knex');

class Board {
  static async create(board) {
    return await knex('boards').insert(board).returning('*');
  }

  static async findById(id) {
    return await knex('boards').where({ id }).first();
  }

  static async getAll() {
    return await knex('boards').select('*');
  }

  static async update(id, board) {
    return await knex('boards').where({ id }).update(board).returning('*');
  }

  static async delete(id) {
    return await knex('boards').where({ id }).del();
  }
}

module.exports = Board;
```

#### 3.3. Task modeli

```js
// models/Task.js
const knex = require('../db/knex');

class Task {
  static async create(task) {
    return await knex('tasks').insert(task).returning('*');
  }

  static async findById(id) {
    return await knex('tasks').where({ id }).first();
  }

  static async getAll(boardId) {
    return await knex('tasks').where({ boardId }).select('*');
  }

  static async update(id, task) {
    return await knex('tasks').where({ id }).update(task).returning('*');
  }

  static async delete(id) {
    return await knex('tasks').where({ id }).del();
  }
}

module.exports = Task;
```

### 4. Routes Fayllari

#### 4.1. Autentifikatsiya yo'llari

`routes/auth.js`:

```js
// routes/auth.js
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const router = express.Router();

router.post('/register', async (req, res) => {
  const { name, email, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);
  try {
    const user = await User.create({ name, email, password: hashedPassword });
    res.status(201).json({ id: user[0].id, name: user[0].name, email: user[0].email });
  } catch (error) {
    res.status(400).json({ error: 'User could not be created' });
  }
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findByEmail(email);
    if (!user) {
      return res.status(400).json({ error: 'Invalid email or password' });
    }
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ error: 'Invalid email or password' });
    }
    res.status(200).json({ id: user.id, name: user.name, email: user.email });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
```

#### 4.2. User yo'llari

`routes/users.js`:

```js
// routes/users.js
const express = require('express');
const User = require('../models/User');
const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const users = await User.getAll();
    res.status(200).json(users);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

router.get('/:userId', async (req, res) => {
  try {
    const user = await User.findById(req.params.userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    const { password, ...userData } = user;
    res.status(200).json(userData);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

router.put('/:userId', async (req, res) => {
  try {
    const user = await User.update(req.params.userId, req.body);
    res.status(200).json(user[0]);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

router.delete('/:userId', async (req, res) => {
  try {
    await User.delete(req.params.userId);
    res.status(204).json({ message: 'User deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
```

*/