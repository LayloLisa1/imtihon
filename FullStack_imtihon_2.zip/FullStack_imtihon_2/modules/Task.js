const db = require('../db/connection');

class Task {
  static async create(task) {
    return await db('tasks').insert(task).returning('*');
  }

  static async findById(id) {
    return await db('tasks').where({ id }).first();
  }

  static async getAll(boardId) {
    return await db('tasks').where({ boardId }).select('*');
  }

  static async update(id, task) {
    return await db('tasks').where({ id }).update(task).returning('*');
  }

  static async delete(id) {
    return await db('tasks').where({ id }).del();
  }
}

module.exports = Task;