exports.up = function(knex) {
    return knex.schema.createTable('tasks', (table) => {
      table.increments('id').primary();
      table.string('title').notNullable();
      table.integer('order').notNullable();
      table.string('description').nullable();
      table.integer('userId').references('id').inTable('users').onDelete('SET NULL');
      table.integer('boardId').references('id').inTable('boards').onDelete('CASCADE');
      table.integer('columnId').nullable();
    });
  };
  exports.down = function(knex) {
    return knex.schema.dropTable('tasks');
  };