const db = require('../db/connection');

class Board {
  static async create(board) {
    return await db('boards').insert(board).returning('*');
  }

  static async findById(id) {
    return await db('boards').where({ id }).first();
  }

  static async getAll() {
    return await db('boards').select('*');
  }

  static async update(id, board) {
    return await db('boards').where({ id }).update(board).returning('*');
  }

  static async delete(id) {
    return await db('boards').where({ id }).del();
  }
}

module.exports = Board;