const db = require('../db/connection');

class User {
  static async create(user) {
    return await db('users').insert(user).returning('*');
  }

  static async findByEmail(email) {
    return await db('users').where({ email }).first();
  }

  static async findById(id) {
    return await db('users').where({ id }).first();
  }

  static async getAll() {
    return await db('users').select('id', 'name', 'email');
  }

  static async update(id, user) {
    return await db('users').where({ id }).update(user).returning('*');
  }

  static async delete(id) {
    return await db('users').where({ id }).del();
  }
}

module.exports = User;